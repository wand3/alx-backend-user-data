uniqueels session auth
